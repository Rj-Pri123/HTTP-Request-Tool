import asyncio
import aiohttp
import time
from collections import Counter
from tkinter import *
from tkinter import messagebox
from datetime import datetime
import threading

# Global control flags and data
status_codes = []
response_times = []
request_times = []
errors = []
stop_flag = threading.Event()

# Async fetch request
async def fetch(session, url, index, log_callback):
    if stop_flag.is_set():
        return
    start_time = time.time()
    timestamp = datetime.now().strftime("%H:%M:%S")

    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as response:
            elapsed = time.time() - start_time
            status_codes.append(response.status)
            response_times.append(elapsed)
            request_times.append(timestamp)
            log_callback(f"✅ Request {index + 1} at {timestamp}: {response.status} in {elapsed:.2f}s")
    except Exception as e:
        status_codes.append('Error')
        response_times.append(None)
        request_times.append(timestamp)
        errors.append(str(e))
        log_callback(f"❌ Request {index + 1} at {timestamp} failed: {e}")

# Main request runner
async def run_requests(url, count, log_callback, done_callback):
    connector = aiohttp.TCPConnector(limit=100)
    tasks = []

    async with aiohttp.ClientSession(connector=connector) as session:
        for i in range(count):
            if stop_flag.is_set():
                break
            task = asyncio.create_task(fetch(session, url, i, log_callback))
            tasks.append(task)
        await asyncio.gather(*tasks)

    if not stop_flag.is_set():
        done_callback()

# Threaded runner
def threaded_run(url, count, log_callback, done_callback):
    asyncio.run(run_requests(url, count, log_callback, done_callback))

# GUI - Start Button Handler
def start_analysis():
    stop_flag.clear()
    url = url_entry.get().strip()
    try:
        count = int(requests_entry.get().strip())
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number of requests.")
        return

    if not url:
        messagebox.showerror("Missing URL", "Please enter a URL to test.")
        return

    clear_data()
    log_callback = lambda text: append_log(text)
    done_callback = show_summary

    threading.Thread(target=threaded_run, args=(url, count, log_callback, done_callback)).start()

# Auto Start with Countdown
def start_auto():
    stop_flag.clear()
    try:
        counter = int(requests_entry.get().strip())
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number.")
        return

    url = url_entry.get().strip()
    if not url:
        messagebox.showerror("Missing URL", "Please enter a URL.")
        return

    def auto_loop():
        for i in range(counter, 0, -1):
            if stop_flag.is_set():
                break
            requests_entry.delete(0, END)
            requests_entry.insert(0, str(i))
            start_analysis()
            time.sleep(10)

    threading.Thread(target=auto_loop).start()

# Stop Button Handler
def stop_analysis():
    stop_flag.set()
    append_log("🛑 Stopped by user.")

# Summary
def show_summary():
    success = status_codes.count(200)
    failed = len(status_codes) - success
    percent_success = (success / len(status_codes)) * 100 if status_codes else 0
    total_time = sum([t for t in response_times if t is not None])

    append_log("\n📊 Summary:")
    append_log(f"🔁 Total Requests: {len(status_codes)}")
    append_log(f"✅ Successful: {success}")
    append_log(f"❌ Failed: {failed}")
    append_log(f"📈 Success Rate: {percent_success:.2f}%")
    append_log(f"🕒 Total Time Spent: {total_time:.2f} seconds")

    if errors:
        append_log("🚨 Errors:")
        error_types = Counter(errors)
        for err, count in error_types.items():
            append_log(f"   - {err} ➤ {count} times")

# Clear and Reset
def clear_data():
    status_codes.clear()
    response_times.clear()
    request_times.clear()
    errors.clear()
    log_output.delete(1.0, END)

# Log Output
def append_log(text):
    log_output.insert(END, text + "\n")
    log_output.see(END)  # Auto-scroll

# GUI Layout
app = Tk()
app.title("💎 HTTP Request Analysis Tool ")
app.geometry("750x550")
app.config(bg="#f5f8ff")

Label(app, text="🔗 URL:", bg="#f5f8ff", font=("Arial", 12)).pack(pady=(10, 0))
url_entry = Entry(app, width=70, font=("Arial", 12))
url_entry.pack(pady=(0, 10))

Label(app, text="🔁 Number of Requests:", bg="#f5f8ff", font=("Arial", 12)).pack()
requests_entry = Entry(app, width=20, font=("Arial", 12))
requests_entry.pack(pady=(0, 10))

button_frame = Frame(app, bg="#f5f8ff")
button_frame.pack(pady=5)

Button(button_frame, text="🚀 Start Test", command=start_analysis, bg="#4CAF50", fg="white", width=15).grid(row=0, column=0, padx=5)
Button(button_frame, text="🔁 Start Auto", command=start_auto, bg="#2196F3", fg="white", width=15).grid(row=0, column=1, padx=5)
Button(button_frame, text="🛑 Stop", command=stop_analysis, bg="#f44336", fg="white", width=15).grid(row=0, column=2, padx=5)

log_output = Text(app, height=20, width=90, font=("Courier", 10), bg="#eef4ff")
log_output.pack(pady=10)

app.mainloop()
